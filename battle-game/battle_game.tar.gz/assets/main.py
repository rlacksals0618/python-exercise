import asyncio
import pygame  # noqa: F401
from batgame import main

asyncio.run(main())
